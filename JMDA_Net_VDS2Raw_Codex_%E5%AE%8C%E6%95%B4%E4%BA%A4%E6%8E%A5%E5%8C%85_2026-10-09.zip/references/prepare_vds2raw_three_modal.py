#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""VDS2Raw v2 three-class, three-input preparation (Python 3.9+).

Step 1 (review): make annotated four-channel preview PNGs and a human review CSV.
Step 2 (build): export raw RGB/NIR images and train-only-normalized AIS vectors.

NEVER alters raw TIFF/JSON, crop .npy files, or the existing domain split.
Band order is NOT inferred from image shape; build requires explicit declaration.
Dependencies: numpy, pillow. No torch required.
"""
import argparse
import ast
import csv
import json
import math
import re
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

PARTS = ('source_train', 'target_train', 'target_val', 'target_test')
CLASS_IDS = {'Cargo': 0, 'Fishing': 1, 'Sailing & Pleasure': 2}
EXPECTED_TYPE = {'Cargo': {'Cargo'}, 'Fishing': {'Fishing'},
                 'Sailing & Pleasure': {'Sailing', 'Pleasure'}}
BANDS = ('B2', 'B3', 'B4', 'B8')
TRAIN_PARTS = ('source_train', 'target_train')


def read_csv(path):
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def write_csv(path, rows, cols):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)


def read_manifest(crops):
    p = crops / 'crop_manifest.csv'
    if not p.is_file():
        raise FileNotFoundError('Missing crop manifest: ' + str(p))
    rows = read_csv(p)
    needed = {'sample_id','partition','label','label_id','split','scene',
              'annotation_id','crop_relpath','qc_flags','mmsi'}
    if not rows or not needed.issubset(rows[0]):
        raise ValueError('Invalid/empty crop_manifest.csv')
    ids = set()
    for r in rows:
        if r['sample_id'] in ids:
            raise ValueError('Duplicate sample ID: ' + r['sample_id'])
        ids.add(r['sample_id'])
        if r['partition'] not in PARTS or r['label'] not in CLASS_IDS:
            raise ValueError('Unexpected split or label at: ' + r['sample_id'])
        if int(r['label_id']) != CLASS_IDS[r['label']]:
            raise ValueError('Unexpected label_id: ' + r['sample_id'])
    return rows


def within(base, rel):
    base = base.resolve()
    dest = (base / rel.replace('\\','/')).resolve()
    if base not in dest.parents:
        raise ValueError('Unsafe relative file path: ' + rel)
    return dest


def load_crop(crops, r):
    path = within(crops, r['crop_relpath'])
    arr = np.load(str(path), allow_pickle=False)
    if arr.ndim != 3 or arr.shape[2] != 4 or arr.dtype != np.uint16:
        raise ValueError('Expected (H,W,4) uint16 at %s; got %s/%s'
                         % (path, arr.shape, arr.dtype))
    return arr


def parse_bbox(value):
    v = ast.literal_eval(value)
    if not isinstance(v, (list,tuple)) or len(v) != 4:
        raise ValueError('Invalid bounding box: ' + str(value))
    return tuple(map(float, v))


def band_boxes(row):
    return [parse_bbox(row[b+'_bbox']) for b in BANDS]


def relative_boxes(row):
    x0, y0 = float(row['crop_x0']), float(row['crop_y0'])
    return [(x-x0,y-y0,w,h) for x,y,w,h in band_boxes(row)]


def bbox_union(boxes):
    return (min(b[0] for b in boxes), min(b[1] for b in boxes),
            max(b[0]+b[2] for b in boxes), max(b[1]+b[3] for b in boxes))


def neighbor_index(path):
    if not path:
        return {}
    lookup = defaultdict(dict)
    for r in read_csv(path):
        lookup[r['scene']][str(r['annotation_id'])] = r
    return lookup


def make_gray(channel):
    a = channel.astype(np.float32)
    v = a[np.isfinite(a) & (a > 0)]
    if not len(v):
        return np.zeros(a.shape, dtype=np.uint8)
    lo, hi = np.percentile(v, [1, 99.5])
    if hi <= lo:
        hi = lo + 1
    return (np.clip((a - lo) * 255.0/(hi - lo), 0, 255)).astype(np.uint8)


def render_review(crops, row, outpath, neighbors):
    from PIL import Image, ImageDraw
    arr = load_crop(crops, row)
    size = 256
    tile_h, header = size, 34
    board = Image.new('RGB', (size*4, tile_h+header), 'white')
    draw = ImageDraw.Draw(board)
    scale_x = size / arr.shape[1]
    scale_y = size / arr.shape[0]
    target = bbox_union(relative_boxes(row))
    x0, y0 = float(row['crop_x0']), float(row['crop_y0'])
    nb_boxes = []
    ids = [s for s in row.get('other_ship_annotation_ids','').split('|') if s]
    for ident in ids:
        rr = neighbors.get(row['scene'], {}).get(ident)
        if rr:
            bx = bbox_union(band_boxes(rr))
            nb_boxes.append(tuple(z - (x0 if i % 2 == 0 else y0) for i,z in enumerate(bx)))
    for c in range(4):
        gray = Image.fromarray(make_gray(arr[..., c]), 'L')
        resized = gray.resize((size,size), Image.NEAREST).convert('RGB')
        board.paste(resized, (c*size, header))
        draw.text((c*size+7,8), 'channel %d (band order unverified)' % c, fill='black')
        def draw_box(b, color, width=3):
            x1,y1,x2,y2=b
            draw.rectangle((int(c*size+x1*scale_x), int(header+y1*scale_y),
                            int(c*size+x2*scale_x), int(header+y2*scale_y)),
                           outline=color,width=width)
        draw_box(target, 'yellow', 3)
        for box in nb_boxes:
            draw_box(box, 'red', 2)
    outpath.parent.mkdir(parents=True,exist_ok=True)
    board.save(str(outpath))


def do_review(args):
    crops = args.crops.resolve()
    rows = read_manifest(crops)
    dest = args.out.resolve()
    dest.mkdir(parents=True, exist_ok=True)
    decision_file = dest / 'review_decisions.csv'
    old = {}
    if decision_file.is_file():
        if args.reset_decisions:
            print('WARNING: --reset-decisions will overwrite previous review decisions.')
        else:
            old = {r['sample_id']: r for r in read_csv(decision_file)}
    neighbors = neighbor_index(args.all_annotations_csv)
    decisions = []
    normals = [r for r in rows if not r['qc_flags']]
    normal_ids = set(r['sample_id'] for r in normals[:args.normal_previews])
    flags = Counter()
    for i, r in enumerate(rows, 1):
        flagged = bool(r['qc_flags'])
        for flag in r['qc_flags'].split('|'):
            if flag: flags[flag] += 1
        previous = old.get(r['sample_id'], {})
        decision = previous.get('decision') or ('pending' if flagged else 'keep')
        if decision not in ('pending','keep','drop'):
            raise ValueError('Invalid previous decision for %s: %s' % (r['sample_id'],decision))
        decisions.append({'sample_id':r['sample_id'], 'partition':r['partition'],
                          'label':r['label'], 'qc_flags':r['qc_flags'],
                          'other_ship_count':r.get('other_ship_count','0'),
                          'decision':decision,'notes':previous.get('notes','')})
        if flagged or r['sample_id'] in normal_ids:
            safe = re.sub(r'[^A-Za-z0-9._-]', '_', r['sample_id'])
            group = 'flagged' if flagged else 'normal_examples'
            render_review(crops, r, dest/'previews'/group/(safe+'.png'), neighbors)
        if i % 50 == 0:
            print('Review prepared: %d/%d' % (i,len(rows)),flush=True)
    cols = ['sample_id','partition','label','qc_flags','other_ship_count','decision','notes']
    write_csv(decision_file, decisions, cols)
    report={'samples':len(rows),'flagged':sum(bool(x['qc_flags']) for x in rows),
            'no_flag':len(normals),'qc_flag_counts':dict(flags),
            'decision_counts':dict(Counter(r['decision'] for r in decisions)),
            'instruction':'Review flagged previews; edit decision to keep/drop. Do not leave pending before build.'}
    (dest/'review_summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Review CSV:',decision_file)
    print('Flagged:',report['flagged'],'Normal:',len(normals))
    print('Decisions:',report['decision_counts'])
    print('Yellow rectangles are target union bboxes; red rectangles are annotated neighbor bboxes.')


def parse_channels(text):
    items = [x.strip().upper() for x in text.split(',')]
    if len(items) != 4 or set(items) != set(BANDS):
        raise ValueError('--band-order must be a permutation of B2,B3,B4,B8')
    return {band:i for i,band in enumerate(items)},items


def first_info(a):
    vals = a.get('info') or []
    if isinstance(vals, dict):
        return vals
    if isinstance(vals,list):
        return next((x for x in vals if isinstance(x,dict)), {})
    return {}


def normalize_mmsi(v):
    try:
        return str(int(float(v))) if float(v)>0 else ''
    except (TypeError,ValueError,OverflowError):
        return ''


def normalize_nav(v):
    return ' '.join(str(v).strip().lower().split()) if v is not None else ''


def number(v, lo, hi):
    try:
        num = float(v)
        if math.isfinite(num) and lo <= num <= hi:
            return num
    except (ValueError,TypeError,OverflowError):
        pass
    return None


def lookup_annotations(root):
    # Only B2 JSON is needed; all four band annotation IDs have already been checked.
    lookup={}
    for split in ('train','val','test'):
        file=root/'annotations'/(split+'__band_2.json')
        data=json.loads(file.read_text(encoding='utf-8-sig'))
        images={str(im['id']): im for im in data.get('images',[])}
        for a in data.get('annotations',[]):
            im=images.get(str(a.get('image_id')))
            if im is None:
                continue  # Ignore foreign annotations.
            scene=Path(str(im['file_name']).replace('\\','/')).name
            key=(split,scene,str(a['id']))
            if key in lookup:
                raise ValueError('Duplicate valid AIS annotation key: '+str(key))
            lookup[key]=a
    return lookup


def load_ais(root, row, annotations):
    key=(row['split'],row['scene'],str(row['annotation_id']))
    a=annotations.get(key)
    if a is None:
        raise ValueError('No COCO annotation for: '+str(key))
    mm=normalize_mmsi(a.get('mmsi',a.get('MMSI')))
    if mm!=normalize_mmsi(row['mmsi']):
        raise ValueError('MMSI differs from split manifest: '+row['sample_id'])
    info=first_info(a)
    typ=str(info.get('Ship type') or '').strip()
    if typ not in EXPECTED_TYPE[row['label']]:
        raise ValueError('Ship type / class mismatch: %s / %s' % (row['sample_id'],typ))
    # Do not include type, name, MMSI, coords, acquisition day or timestamp as network input.
    return {'heading':number(info.get('Heading'),0,359.9999),
            'length':number(info.get('Length'),0.001,1000),
            'width':number(info.get('Width'),0.001,200),
            'nav':normalize_nav(info.get('Navigational status')),
            'timestamp':str(info.get('Timestamp') or ''),
            'mmsi':mm,'raw_type':typ}


def fit_transform(rows, ais_by_id):
    train=[ais_by_id[r['sample_id']] for r in rows if r['partition'] in TRAIN_PARTS]
    if not train:
        raise ValueError('No training samples to fit AIS transforms')
    scalers={}
    for key in ('length','width'):
        vals=np.array([a[key] for a in train if a[key] is not None],dtype=np.float64)
        if not len(vals):
            raise ValueError('All AIS %s values absent from training samples' % key)
        mean=float(vals.mean())
        std=float(vals.std())
        scalers[key]={'mean':mean,'std':max(std,1e-6),'n':len(vals)}
    known=sorted({a['nav'] for a in train if a['nav']})
    names=['<UNKNOWN>']+known
    nav_idx={s:i for i,s in enumerate(names)}
    dim=4+len(names)
    arrays={}
    for r in rows:
        a=ais_by_id[r['sample_id']]
        f=np.zeros(dim,dtype=np.float32)
        mask=np.zeros(dim,dtype=np.float32)
        if a['heading'] is not None:
            rad=math.radians(a['heading'])
            f[0],f[1]=math.sin(rad),math.cos(rad)
            mask[0:2]=1
        for j,key in ((2,'length'),(3,'width')):
            if a[key] is not None:
                f[j]=(a[key]-scalers[key]['mean'])/scalers[key]['std']
                mask[j]=1
        ix=nav_idx.get(a['nav'],0)
        f[4+ix]=1
        mask[4:]=1 if a['nav'] else 0
        arrays[r['sample_id']]=(f,mask)
    schema={'ais_feature_names':['heading_sin','heading_cos','length_z','width_z']+
            ['nav_'+str(s) for s in names],
            'feature_dim':dim,'train_partitions':list(TRAIN_PARTS),
            'scalers':scalers,'nav_vocabulary':names,
            'missing_value_policy':'value 0 + ais_mask 0 for invalid/missing continuous fields',
            'excluded_input_fields':['Ship type','Cargo type','Name','MMSI','coordinates','distance','Timestamp','day','scene']}
    return arrays,schema


def do_build(args):
    if not args.band_order:
        raise ValueError('Build requires --band-order; this is not inferred from TIFF shape')
    if args.confirm_band_order != 'I_VERIFIED':
        raise ValueError('Build requires --confirm-band-order I_VERIFIED. Confirm mapping using the dataset construction/documentation first.')
    bandmap,declared=parse_channels(args.band_order)
    root=args.root.resolve()
    crops=args.crops.resolve()
    out=args.out.resolve()
    if out==root or root in out.parents or out==crops or crops in out.parents:
        raise ValueError('Output must not be inside original dataset or crop directory')
    rows=read_manifest(crops)
    decisions_path=args.review_dir/'review_decisions.csv'
    if not decisions_path.is_file():
        raise FileNotFoundError('Run review mode first: '+str(decisions_path))
    choices=read_csv(decisions_path)
    by_id={r['sample_id']:r for r in choices}
    if len(choices)!=len(rows) or len(by_id)!=len(rows):
        raise ValueError('Review decisions must cover exactly all crop_manifest samples')
    expected={r['sample_id'] for r in rows}
    if set(by_id)!=expected:
        raise ValueError('Review sample IDs mismatch')
    for r in rows:
        c=by_id[r['sample_id']]
        if c['decision'] not in ('keep','drop','pending'):
            raise ValueError('Unrecognized review decision: '+r['sample_id'])
        if r['qc_flags'] and c['decision']=='keep' and not c.get('notes','').strip():
            raise ValueError('Flagged sample approved without review note: '+r['sample_id'])
    pending=[r['sample_id'] for r in choices if r['decision']=='pending']
    if pending and args.pending_policy=='error':
        raise ValueError('%d samples pending review, e.g. %s. Mark keep/drop in review_decisions.csv, '
                         'or use --pending-policy exclude.' % (len(pending),pending[:3]))
    selected=[r for r in rows if by_id[r['sample_id']]['decision']=='keep']
    if not selected:
        raise ValueError('No approved samples')
    # Validate partition safety after filtering (MMSI and granule scene).
    mm_groups=defaultdict(set)
    scene_groups=defaultdict(set)
    for r in selected:
        mm=normalize_mmsi(r['mmsi'])
        if not mm:
            raise ValueError('Missing MMSI for approved sample: '+r['sample_id'])
        mm_groups[mm].add(r['partition'])
        scene_groups[r['scene']].add(r['partition'])
    leaking_mmsi={k:v for k,v in mm_groups.items() if len(v)>1}
    leaking_scenes={k:v for k,v in scene_groups.items() if len(v)>1}
    if leaking_mmsi or leaking_scenes:
        raise ValueError('Cross-partition overlap: MMSI=%s, scene=%s' %
                         (list(leaking_mmsi)[:5],list(leaking_scenes)[:5]))
    annotations=lookup_annotations(root)
    ais_by_id={r['sample_id']:load_ais(root,r,annotations) for r in selected}
    numeric, ais_schema=fit_transform(selected,ais_by_id)
    if out.exists() and any(out.iterdir()):
        raise FileExistsError('Build output directory is not empty. Choose a fresh --out to avoid stale .npz files: ' + str(out))
    out.mkdir(parents=True,exist_ok=True)
    records=[]
    invalid=Counter()
    for i,r in enumerate(selected,1):
        arr=load_crop(crops,r)
        rgb=arr[..., [bandmap['B4'],bandmap['B3'],bandmap['B2']]].transpose(2,0,1).copy()
        nir=arr[..., bandmap['B8']][None,...].copy()
        ais, mask=numeric[r['sample_id']]
        subdir=Path('samples')/r['partition'] / ('Sailing_Pleasure' if r['label']=='Sailing & Pleasure' else r['label'])
        file=Path(r['crop_relpath']).stem+'.npz'
        rel=subdir/file
        dest=out/rel
        dest.parent.mkdir(parents=True,exist_ok=True)
        np.savez_compressed(str(dest),rgb=rgb,nir=nir,ais=ais,ais_mask=mask,
                            label=np.array(int(r['label_id']), dtype=np.int64))
        a=ais_by_id[r['sample_id']]
        for name in ('heading','length','width'):
            if a[name] is None: invalid[name]+=1
        if not a['nav']: invalid['nav']+=1
        records.append({'sample_id':r['sample_id'],'partition':r['partition'],
                        'label':r['label'],'label_id':r['label_id'],
                        'npz_relpath':rel.as_posix(),
                        'source_crop_relpath':r['crop_relpath'],
                        'scene':r['scene'],'day':r['day'],'original_split':r['split'],
                        'annotation_id':r['annotation_id'],'mmsi':r['mmsi'],
                        'qc_flags':r['qc_flags'], 'review_note':by_id[r['sample_id']].get('notes',''),
                        'ais_heading_valid':int(a['heading'] is not None),
                        'ais_length_valid':int(a['length'] is not None),
                        'ais_width_valid':int(a['width'] is not None),
                        'ais_nav_valid':int(bool(a['nav'])),
                        'ais_timestamp_metadata_only':a['timestamp']})
        if i%50==0:
            print('Three-input samples built: %d/%d' % (i,len(selected)),flush=True)
    cols=list(records[0].keys())
    write_csv(out/'dataset_manifest.csv',records,cols)
    ais_schema['user_declared_tiff_channel_order']=declared
    ais_schema['rgb_band_order']=['B4','B3','B2']
    ais_schema['nir_band']='B8'
    ais_schema['raw_image_dtype']='uint16'
    ais_schema['image_normalization']='Not applied: calculate parameters from training partitions in downstream loader.'
    (out/'feature_schema.json').write_text(json.dumps(ais_schema,ensure_ascii=False,indent=2),encoding='utf-8')
    by_part_class=defaultdict(Counter)
    for r in selected:
        by_part_class[r['partition']][r['label']]+=1
    absent_classes={part:[cls for cls in CLASS_IDS if by_part_class[part][cls]==0] for part in PARTS}
    absent_classes={k:v for k,v in absent_classes.items() if v}
    report={'original_count':len(rows),'included':len(selected),
            'excluded_by_decision':sum(by_id[r['sample_id']]['decision']=='drop' for r in rows),
            'excluded_pending':len(pending),'partition_counts':dict(Counter(r['partition'] for r in selected)),
            'class_counts':dict(Counter(r['label'] for r in selected)),
            'class_counts_by_partition':{p:dict(by_part_class[p]) for p in PARTS},
            'partitions_missing_classes':absent_classes,
            'ais_invalid_field_counts':dict(invalid),
            'band_order_explicitly_declared_by_user':declared,
            'note':'SDA label-safe: AIS Ship type used for label verification only. Spectral image calibration not applied.'}
    (out/'build_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DONE: %d samples written to %s' % (len(selected),out))
    print('Per partition:',report['partition_counts'])
    if absent_classes:
        print('WARNING: some partitions are missing target classes:',absent_classes)
    print('Reports: dataset_manifest.csv, feature_schema.json, build_report.json')


def main():
    parser=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    sub=parser.add_subparsers(dest='mode',required=True)
    review=sub.add_parser('review',help='Create review_decisions.csv and flagged-channel visualizations')
    review.add_argument('--crops',type=Path,required=True)
    review.add_argument('--out',type=Path,required=True)
    review.add_argument('--all-annotations-csv',type=Path)
    review.add_argument('--normal-previews',type=int,default=12)
    review.add_argument('--reset-decisions',action='store_true')
    build=sub.add_parser('build',help='Export RGB/NIR raw images and train-only-normalized AIS features')
    build.add_argument('--root',type=Path,required=True,help='Original VDS2Raw (v2)')
    build.add_argument('--crops',type=Path,required=True)
    build.add_argument('--review-dir',type=Path,required=True)
    build.add_argument('--out',type=Path,required=True)
    build.add_argument('--band-order',required=True,help='TIFF channel order, e.g. B2,B3,B4,B8')
    build.add_argument('--confirm-band-order',default='',help='Type I_VERIFIED once you verified band mapping')
    build.add_argument('--pending-policy',choices=('error','exclude'),default='error')
    args=parser.parse_args()
    if args.mode=='review':
        if args.normal_previews<0: parser.error('--normal-previews cannot be negative')
        do_review(args)
    else:
        do_build(args)


if __name__=='__main__':
    main()
