#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Crop VDS2Raw three-class split without changing the original scenes.

One shared spatial window is extracted from all four raw TIFF channels.
Channel-to-Sentinel-band mapping is deliberately NOT assumed or changed.
Python 3.9+; pip install numpy tifffile pillow
"""
import argparse
import ast
import csv
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import tifffile

BANDS = ('B2', 'B3', 'B4', 'B8')
PARTS = ('source_train', 'target_train', 'target_val', 'target_test')
LABEL_IDS = {'Cargo': 0, 'Fishing': 1, 'Sailing & Pleasure': 2}
LABEL_DIRS = {'Cargo': 'Cargo', 'Fishing': 'Fishing', 'Sailing & Pleasure': 'Sailing_Pleasure'}


def load_rows(path):
    with path.open('r', encoding='utf-8-sig', newline='') as stream:
        reader = csv.DictReader(stream)
        fields = set(reader.fieldnames or [])
        needed = {'sample_id', 'partition', 'label', 'label_id', 'image_relpath', 'scene', 'annotation_id'}
        needed.update('%s_bbox' % b for b in BANDS)
        if not needed.issubset(fields):
            raise ValueError('Not a valid split_manifest.csv, missing: ' + ','.join(sorted(needed - fields)))
        rows = list(reader)
    seen = set()
    for r in rows:
        ident = r['sample_id']
        if ident in seen:
            raise ValueError('Duplicate sample_id: ' + ident)
        seen.add(ident)
        if r['partition'] not in PARTS or r['label'] not in LABEL_IDS:
            raise ValueError('Invalid partition or label at ' + ident)
        if int(r['label_id']) != LABEL_IDS[r['label']]:
            raise ValueError('Unexpected class ID at ' + ident)
    return rows


def get_boxes(row):
    boxes = {}
    for band in BANDS:
        value = ast.literal_eval(row[band + '_bbox'])
        if not isinstance(value, (tuple, list)) or len(value) != 4:
            raise ValueError('Invalid bbox for %s' % band)
        x, y, w, h = map(float, value)
        if not all(math.isfinite(z) for z in (x, y, w, h)) or w <= 0 or h <= 0:
            raise ValueError('Invalid bbox values for %s' % band)
        boxes[band] = (x, y, w, h)
    return boxes


def annotated_neighbor_centers(path):
    """Load centers for all 695 original annotations, not only three-class rows."""
    if path is None:
        return {}
    groups = defaultdict(list)
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        for row in csv.DictReader(f):
            boxes = get_boxes(row)
            minx = min(v[0] for v in boxes.values())
            miny = min(v[1] for v in boxes.values())
            maxx = max(v[0] + v[2] for v in boxes.values())
            maxy = max(v[1] + v[3] for v in boxes.values())
            groups[row['scene']].append((str(row['annotation_id']),
                                         (minx + maxx) / 2,
                                         (miny + maxy) / 2))
    return groups


def crop_view(img, size, cx, cy):
    # Spatial window applies identically to all four channels; no interpolation.
    left = math.floor(cx - size / 2)
    top = math.floor(cy - size / 2)
    right, bottom = left + size, top + size
    h, w, _ = img.shape
    x0, y0 = max(0, left), max(0, top)
    x1, y1 = min(w, right), min(h, bottom)
    result = np.zeros((size, size, 4), dtype=np.uint16)
    if x1 > x0 and y1 > y0:
        result[y0 - top:y1 - top, x0 - left:x1 - left, :] = img[y0:y1, x0:x1, :]
    padded = ((x0 - left) + (right - x1), (y0 - top) + (bottom - y1))
    return result, left, top, padded


def preview_png(raw, destination, title):
    # Only display/preview data is stretched to 8-bit; saved .npy stays 16-bit.
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        raise RuntimeError('Pillow is required for previews; install: pip install pillow')
    tile = 180
    board = Image.new('RGB', (tile * 4, tile + 30), 'white')
    draw = ImageDraw.Draw(board)
    for channel in range(4):
        a = raw[..., channel].astype(np.float32)
        valid = a[a > 0]
        if valid.size:
            lo, hi = np.percentile(valid, [1, 99.5])
            if hi <= lo:
                lo, hi = float(valid.min()), float(valid.max())
            if hi > lo:
                a = (np.clip(a, lo, hi) - lo) * (255.0 / (hi - lo))
            else:
                a[:] = 0
        else:
            a[:] = 0
        frame = Image.fromarray(a.clip(0, 255).astype('uint8'), 'L')
        frame = frame.resize((tile, tile), Image.Resampling.NEAREST if hasattr(Image, 'Resampling') else Image.NEAREST).convert('RGB')
        board.paste(frame, (tile * channel, 30))
        draw.text((tile * channel + 5, 5), 'channel %d (band unverified)' % channel, fill='black')
    # title is stored in file name; not printed across channels
    board.save(destination)


def main():
    parser = argparse.ArgumentParser(description='Lossless 4-channel ship cropping from VDS2Raw split_manifest.csv')
    parser.add_argument('--root', type=Path, required=True, help='VDS2Raw (v2) dataset directory')
    parser.add_argument('--split-csv', type=Path, required=True, help='threeclass_split/split_manifest.csv')
    parser.add_argument('--out', type=Path, required=True, help='NEW output folder for cropped images')
    parser.add_argument('--crop-size', type=int, default=96, help='Crop H=W in native pixels (default: 96)')
    parser.add_argument('--preview-count', type=int, default=24, help='Number of four-channel preview mosaics')
    parser.add_argument('--all-annotations-csv', type=Path,
                        help='stage2 annotation_candidates.csv for detecting other annotated ships inside crops')
    args = parser.parse_args()
    if args.crop_size < 16 or args.crop_size > 512:
        parser.error('--crop-size must be in [16,512]')
    if args.preview_count < 0:
        parser.error('--preview-count must not be negative')
    root = args.root.resolve()
    out = args.out.resolve()
    if out == root or root in out.parents:
        parser.error('Output folder must be OUTSIDE the original dataset directory')
    rows = load_rows(args.split_csv)
    if not rows:
        raise ValueError('No entries in split_manifest.csv')
    neighbors_by_scene = annotated_neighbor_centers(args.all_annotations_csv)
    out.mkdir(parents=True, exist_ok=True)
    groups = defaultdict(list)
    for r in rows:
        scene = (root / r['image_relpath']).resolve()
        if root not in scene.parents or scene.suffix.lower() not in ('.tif', '.tiff'):
            raise ValueError('Unsafe or unexpected TIFF path: ' + r['image_relpath'])
        groups[scene].append(r)

    preview_n = min(args.preview_count, len(rows))
    indices = set(np.linspace(0, len(rows) - 1, num=preview_n, dtype=int).tolist()) if preview_n else set()
    preview_samples = {r['sample_id'] for i, r in enumerate(rows) if i in indices}
    records, warnings = [], []
    n = len(rows)
    for file_index, (scene_path, samples) in enumerate(sorted(groups.items()), 1):
        print('[%d/%d] %s (%d annotations)' % (file_index, len(groups), scene_path.name, len(samples)), flush=True)
        if not scene_path.is_file():
            raise FileNotFoundError('Missing TIFF: ' + str(scene_path))
        img = tifffile.imread(str(scene_path))
        if img.ndim != 3 or img.shape[-1] != 4 or img.dtype != np.uint16:
            raise ValueError('Expected (H,W,4) uint16 TIFF: %s got %s %s' % (scene_path, img.shape, img.dtype))
        ih, iw, _ = img.shape
        for r in samples:
            boxes = get_boxes(r)
            minx = min(b[0] for b in boxes.values())
            miny = min(b[1] for b in boxes.values())
            maxx = max(b[0] + b[2] for b in boxes.values())
            maxy = max(b[1] + b[3] for b in boxes.values())
            unionw, unionh = maxx - minx, maxy - miny
            cx, cy = (minx + maxx) / 2, (miny + maxy) / 2
            crop, left, top, pad = crop_view(img, args.crop_size, cx, cy)
            checks = []
            if unionw > args.crop_size or unionh > args.crop_size:
                checks.append('union_bbox_larger_than_crop')
            if minx < 0 or miny < 0 or maxx > iw or maxy > ih:
                checks.append('annotation_outside_image')
            if pad != (0, 0):
                checks.append('edge_zero_padding')
            if not crop.any():
                checks.append('all_zero_crop')
            neighbors = [ident for ident, nx, ny in neighbors_by_scene.get(r['scene'], [])
                         if ident != str(r['annotation_id'])
                         and left <= nx < left + args.crop_size
                         and top <= ny < top + args.crop_size]
            if neighbors:
                checks.append('other_annotated_ship_center_in_crop')
            name = '%s__ann_%s.npy' % (scene_path.stem, r['annotation_id'])
            subdir = Path(r['partition']) / LABEL_DIRS[r['label']]
            relative = subdir / name
            dest = out / 'crops' / relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            np.save(dest, crop, allow_pickle=False)
            if r['sample_id'] in preview_samples:
                pv = out / 'previews' / subdir / (name[:-4] + '.png')
                pv.parent.mkdir(parents=True, exist_ok=True)
                preview_png(crop, pv, r['sample_id'])
            rec = dict(r)
            rec.update({'crop_relpath': ('crops/' + relative.as_posix()),
                        'original_height': ih, 'original_width': iw,
                        'crop_size': args.crop_size, 'crop_x0': left, 'crop_y0': top,
                        'union_bbox_width': round(unionw, 4), 'union_bbox_height': round(unionh, 4),
                        'pad_x_total': pad[0], 'pad_y_total': pad[1],
                        'qc_flags': '|'.join(checks), 'crop_status': 'needs_review' if checks else 'ok',
                        'other_ship_count': len(neighbors),
                        'other_ship_annotation_ids': '|'.join(neighbors),
                        'tiff_dtype': 'uint16', 'tiff_channels': 4,
                        'channel_to_band_order': 'UNVERIFIED'})
            records.append(rec)
            if checks:
                warnings.append(rec)
    extras = ['crop_relpath', 'original_height', 'original_width', 'crop_size', 'crop_x0', 'crop_y0',
              'union_bbox_width', 'union_bbox_height', 'pad_x_total', 'pad_y_total', 'qc_flags',
              'crop_status', 'other_ship_count', 'other_ship_annotation_ids',
              'tiff_dtype', 'tiff_channels', 'channel_to_band_order']
    fields = list(rows[0].keys()) + extras
    for filename, entries in [('crop_manifest.csv', records), ('issues_to_review.csv', warnings)]:
        with (out / filename).open('w', newline='', encoding='utf-8-sig') as f:
            wr = csv.DictWriter(f, fieldnames=fields)
            wr.writeheader()
            wr.writerows(entries)
    tally = Counter(x['partition'] for x in records)
    flags = Counter(flag for x in warnings for flag in x['qc_flags'].split('|') if flag)
    report = {'expected': n, 'generated': len(records), 'source_scenes_read': len(groups),
              'partition_counts': dict(tally), 'crop_size': args.crop_size,
              'samples_needing_review': len(warnings), 'qc_flags': dict(flags),
              'note': 'Raw 4 channels saved as uint16 in original TIFF order; NO band order assumed, no RGB conversion, no normalization or resizing.',
              'next_step': 'Verify TIFF channel order and visually inspect preview before deriving RGB/NIR; extract AIS by annotation_id and scene.'}
    (out / 'qc_report.json').write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
    print('\nCrop completed: %d/%d, review=%d' % (len(records), n, len(warnings)))
    print('Partition counts:', dict(tally))
    print('Issue counts:', dict(flags))
    print('Outputs:', out / 'crop_manifest.csv', out / 'issues_to_review.csv', out / 'qc_report.json')


if __name__ == '__main__':
    main()
