#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Reproducible, scene- and MMSI-disjoint three-class day-domain split.

Creates manifests only; does not change original TIFFs or COCO annotations.
"""
import argparse
import ast
import csv
import json
import math
import random
from collections import Counter, defaultdict
from pathlib import Path

LABELS = {'Cargo': ('Cargo', 0), 'Fishing': ('Fishing', 1),
          'Sailing': ('Sailing & Pleasure', 2), 'Pleasure': ('Sailing & Pleasure', 2)}
PARTS = ('target_train', 'target_val', 'target_test')
FIELDS_REQUIRED = ['split', 'day', 'scene', 'annotation_id', 'mmsi',
                   'raw_ship_type', 'all_four_bands_in_metadata', 'mmsi_present']
BANDS = ('B2', 'B3', 'B4', 'B8')

class UnionFind:
    def __init__(self, items):
        self.parent = {x: x for x in items}
    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x
    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[max(ra, rb)] = min(ra, rb)


def write_csv(path, rows, fields):
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        w.writeheader()
        w.writerows(rows)


def valid_box(row, band):
    if row.get(f'{band}_annotation', '0') != '1':
        return False
    try:
        box = ast.literal_eval(row.get(f'{band}_bbox', ''))
        return (isinstance(box, (list, tuple)) and len(box) == 4 and
                all(math.isfinite(float(q)) for q in box) and
                float(box[2]) > 0 and float(box[3]) > 0)
    except (ValueError, SyntaxError, TypeError, OverflowError):
        return False


def load_candidates(path):
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames or any(c not in reader.fieldnames for c in FIELDS_REQUIRED):
            raise ValueError('The input must be the stage2 annotation_candidates.csv; missing required columns.')
        original_fields = list(reader.fieldnames)
        raw = list(reader)
    accepted, excluded, ids = [], [], set()
    for r in raw:
        r = dict(r)
        r['sample_id'] = f"{r['scene']}::{r['annotation_id']}"
        r['image_relpath'] = f"imgs/{r['scene']}"
        if r['sample_id'] in ids:
            raise ValueError('Duplicate sample ID: ' + r['sample_id'])
        ids.add(r['sample_id'])
        if r['raw_ship_type'] not in LABELS:
            reason = 'not_in_official_three_classes'
        elif r['mmsi_present'] != '1' or not r['mmsi'].strip():
            reason = 'missing_mmsi'
        elif r['all_four_bands_in_metadata'] != '1' or any(not valid_box(r, b) for b in BANDS):
            reason = 'missing_or_invalid_band_metadata'
        elif not r['day'] or not r['scene']:
            reason = 'missing_day_or_scene'
        else:
            reason = None
        if reason:
            r['exclusion_reason'] = reason
            excluded.append(r)
            continue
        r['label'], r['label_id'] = LABELS[r['raw_ship_type']]
        accepted.append(r)
    return accepted, excluded, original_fields, len(raw)


def components_by_scene_and_mmsi(rows):
    scenes = sorted({r['scene'] for r in rows})
    uf = UnionFind(scenes)
    mmsi_first = {}
    for r in rows:
        mmsi = r['mmsi']
        if mmsi in mmsi_first:
            uf.union(r['scene'], mmsi_first[mmsi])
        else:
            mmsi_first[mmsi] = r['scene']
    groups = defaultdict(list)
    for r in rows:
        groups[uf.find(r['scene'])].append(r)
    return [groups[k] for k in sorted(groups)]


def assignment_score(sizes, classes, goals, class_goals, minimums=True):
    score = 0.0
    for p in range(3):
        d = sizes[p] - goals[p]
        score += 0.8*d*d / max(6.0, goals[p])
        for c in range(3):
            t = class_goals[p][c]
            z = classes[p][c] - t
            score += 2.0*z*z / max(2.5, t)
            if minimums:
                minimum = 5 if p == 0 else 3
                if classes[p][c] < minimum:
                    score += 70*(minimum - classes[p][c])**2
    return score


def allocate(groups, ratios, seed=2026, restarts=900):
    rng = random.Random(seed)
    total = sum(len(g) for g in groups)
    overall = Counter(int(r['label_id']) for g in groups for r in g)
    goals = [total*p for p in ratios]
    class_goals = [[overall[c]*ratios[p] for c in range(3)] for p in range(3)]
    stats = [(len(g), [sum(int(r['label_id']) == c for r in g) for c in range(3)]) for g in groups]
    best, best_score = None, float('inf')
    for iteration in range(restarts):
        order = list(range(len(groups)))
        rng.shuffle(order)
        order.sort(key=lambda x: -(stats[x][0]+rng.uniform(-3.0,3.0)))
        sizes = [0,0,0]
        classes = [[0,0,0] for _ in range(3)]
        assign = [-1]*len(groups)
        for i in order:
            n, cc = stats[i]
            candidates = []
            for p in range(3):
                sizes[p] += n
                for c in range(3): classes[p][c] += cc[c]
                val = assignment_score(sizes, classes, goals, class_goals, minimums=False)
                candidates.append((val + rng.uniform(-.03,.03), p))
                sizes[p] -= n
                for c in range(3): classes[p][c] -= cc[c]
            chosen = min(candidates)[1]
            assign[i] = chosen
            sizes[chosen] += n
            for c in range(3): classes[chosen][c] += cc[c]
        # Finite local refinement: move a scene/identity group without breaking group safety.
        for _ in range(10):
            improved = False
            ix = list(range(len(groups)))
            rng.shuffle(ix)
            for i in ix:
                old = assign[i]
                n,cc=stats[i]
                base = assignment_score(sizes, classes, goals, class_goals)
                move_to = old
                for p in range(3):
                    if p == old: continue
                    sizes[old] -= n; sizes[p] += n
                    for c in range(3): classes[old][c] -= cc[c]; classes[p][c] += cc[c]
                    score = assignment_score(sizes, classes, goals, class_goals)
                    if score + 1e-8 < base:
                        base = score; move_to = p
                    sizes[old] += n; sizes[p] -= n
                    for c in range(3): classes[old][c] += cc[c]; classes[p][c] -= cc[c]
                if move_to != old:
                    sizes[old] -= n; sizes[move_to] += n
                    for c in range(3): classes[old][c] -= cc[c]; classes[move_to][c] += cc[c]
                    assign[i] = move_to
                    improved = True
            if not improved: break
        final = assignment_score(sizes, classes, goals, class_goals)
        if final < best_score:
            best_score = final
            best = assign[:]
    if best is None:
        raise ValueError('Could not allocate target groups.')
    return best, best_score


def no_overlap(rows, key):
    by = defaultdict(set)
    for r in rows:
        by[r[key]].add(r['partition'])
    return {k: sorted(v) for k,v in by.items() if len(v)>1}


def main():
    ap = argparse.ArgumentParser(description='Split VDS2Raw into official 3 classes for supervised cross-day DA.')
    ap.add_argument('--csv', required=True, type=Path, help='stage2 annotation_candidates.csv')
    ap.add_argument('--out', required=True, type=Path, help='output directory (new files only)')
    ap.add_argument('--source-day', default='day3', help='one filename-derived day prefix')
    ap.add_argument('--seed', type=int, default=2026)
    ap.add_argument('--ratios', nargs=3, type=float, default=[0.60,0.20,0.20],
                    metavar=('TRAIN','VAL','TEST'))
    args = ap.parse_args()
    if any(x <= 0 for x in args.ratios) or abs(sum(args.ratios) - 1.0) > 1e-8:
        ap.error('ratios must be positive and sum to 1')
    data, excluded, original_fields, total_input = load_candidates(args.csv)
    if not data:
        raise ValueError('No eligible three-class samples in CSV.')
    source = [r for r in data if r['day'] == args.source_day]
    target = [r for r in data if r['day'] != args.source_day]
    if not source or not target:
        raise ValueError('Both source and target must contain eligible samples.')
    # We prioritize target observation: remove source-domain copies of target identities.
    target_mmsi = {r['mmsi'] for r in target}
    source_safe = []
    for r in source:
        if r['mmsi'] in target_mmsi:
            x = dict(r)
            x['exclusion_reason'] = 'source_identity_appears_in_target'
            excluded.append(x)
        else:
            source_safe.append(r)
    for r in source_safe:
        r['domain'] = 'source'
        r['partition'] = 'source_train'
    groups = components_by_scene_and_mmsi(target)
    assignments, objective = allocate(groups, args.ratios, args.seed)
    for g,pidx in zip(groups,assignments):
        for r in g:
            r['domain'] = 'target'
            r['partition'] = PARTS[pidx]
    manifest = sorted(source_safe + target, key=lambda r:(r['partition'],r['scene'],int(r['annotation_id'])))
    assert len({r['sample_id'] for r in manifest}) == len(manifest)
    collisions = {'scene': no_overlap(manifest,'scene'), 'mmsi': no_overlap(manifest,'mmsi')}
    if collisions['scene'] or collisions['mmsi']:
        raise AssertionError('Leakage found across partitions: ' + str(collisions))
    bins = defaultdict(Counter)
    scenes = defaultdict(set)
    all_mmsis = defaultdict(set)
    orig = defaultdict(Counter)
    for r in manifest:
        bins[r['partition']][r['label']] += 1
        scenes[r['partition']].add(r['scene'])
        all_mmsis[r['partition']].add(r['mmsi'])
        orig[r['partition']][r['split']] += 1
    labels = ['Cargo','Fishing','Sailing & Pleasure']
    for p in ('source_train',)+PARTS:
        if not all(bins[p][c] for c in labels):
            raise ValueError(f'Partition {p} missing a class: {dict(bins[p])}; change domain or ratios.')
    args.out.mkdir(parents=True, exist_ok=True)
    output_fields = ['sample_id','domain','partition','label','label_id','image_relpath'] + original_fields
    exclusion_fields = ['sample_id','exclusion_reason'] + original_fields
    write_csv(args.out/'split_manifest.csv',manifest,output_fields)
    write_csv(args.out/'excluded_rows.csv',excluded,exclusion_fields)
    report = {
        'protocol': 'provisional supervised cross-day domain adaptation; not official classification split',
        'source_domain': args.source_day,
        'target_domain': f'all filename day prefixes except {args.source_day}',
        'target_ratios': args.ratios,'seed':args.seed,'group_rule':'union of same scene or same MMSI',
        'cross_domain_mmsi_rule':'keep target, exclude overlapping source identities',
        'label_to_id':{'Cargo':0,'Fishing':1,'Sailing & Pleasure':2},
        'total_raw_annotations':total_input,'eligible_threeclass_before_identity_exclusion':len(data),
        'source_before_identity_exclusion':len(source),
        'cross_domain_excluded_source_samples':len(source)-len(source_safe),
        'used_samples':len(manifest), 'excluded_rows':len(excluded),
        'exclusion_reasons':dict(Counter(r['exclusion_reason'] for r in excluded)),
        'partitions':{p:{'samples':sum(bins[p].values()),'classes':{c:bins[p][c] for c in labels},
                           'scenes':len(scenes[p]), 'mmsi':len(all_mmsis[p]),
                           'original_detection_splits':dict(orig[p])}
                      for p in ('source_train',)+PARTS},
        'leakage_check':{'scene_overlap_across_partitions':0,'mmsi_overlap_across_partitions':0},
        'target_allocation_objective':round(objective,6),
        'conditions_before_training':[
            'Inspect full physical 4-channel TIFF order (B2/B3/B4/B8) and verify pixel alignment.',
            'Check bbox errors against TIFF shape; inspect visual crops.',
            'Check AIS numeric values and acquisition-time consistency; exclude Ship type/MMSI/Name from inputs.',
            'Train/val/test use independently locked target scene and MMSI groups.',
            'Verify day-prefix domain shift is meaningful; test never used for model selection.',
            'Original detection train/val/test is repurposed; do not call this the official classification split.'
        ]
    }
    (args.out/'split_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (args.out/'README.txt').write_text(
        'VDS2Raw v2 official-classes three-way supervised cross-day domain adaptation.\n'
        'This is a PROVISIONAL NEW split, NOT the official VDS2Raw classification split.\n'
        'source_train: images from source day prefix, target_*: images from other days.\n'
        'Reconstruct images/AIS from annotations and imgs using original split, scene and annotation_id.\n'
        'Never feed raw Ship type/MMSI/Name to your AIS encoder.\n'
        'See split_report.json for class counts and validity checks.\n',encoding='utf-8')
    print('Official 3 classes; input annotations:', total_input,
          'eligible:', len(data), 'source overlapping identities excluded:',len(source)-len(source_safe))
    for p in ('source_train',)+PARTS:
        print(f'{p:13s}', 'N=',sum(bins[p].values()),'scenes=',len(scenes[p]),
              'classes=',{c:bins[p][c] for c in labels})
    print('Scene leakage=0; MMSI leakage=0 across all four partitions.')
    print('Reports:', args.out.resolve())

if __name__ == '__main__':
    main()
