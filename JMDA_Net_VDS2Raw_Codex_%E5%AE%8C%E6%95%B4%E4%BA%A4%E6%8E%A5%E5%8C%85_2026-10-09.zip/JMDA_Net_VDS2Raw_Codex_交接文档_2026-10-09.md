# JMDA-Net × VDS2Raw v2：新 Codex 对话完整技术交接

> 文档日期：2026-10-09  
> 用途：将历史 Codex 对话（上传文件 `粘贴的文本 (1)(4).txt`，约 8,845 行）及本次 ChatGPT 对话衔接到**新的 Codex 对话**，使其直接接手 `D:\Code\JMDA-Net` 的 VDS2Raw v2 数据处理、三模态模型适配、本地测试与 Linux 服务器正式训练。  
> 本文依据用户已经提供的对话、审计报告、CSV、Python 脚本和运行输出整理；**没有直接访问或执行用户 Windows 仓库和真实 TIFF**。所有“Codex 已修改代码”的叙述是历史对话报告，不代表本次重新核实仓库当前内容。文中“初版协议”“待验证”必须按字面理解。

---

## 0. 立即执行摘要 / 当前真实停留点

**用户最终决策（已确认，不要重复询问）：**

1. **工程仓库**：`D:\Code\JMDA-Net`，即**JMDA-Net 原始工程**；不要切换到 `Dual_D`、So2Sat、M4-SAR 或旧版私有天气实验作为本轮主体。
2. **数据**：`VDS2Raw v2` 原始检测数据（**不是**仅保留裁剪图像的官方分类 ZIP），以 AIS `Ship type` 映射为官方同名三分类：`Cargo`、`Fishing`、`Sailing & Pleasure`。
3. **任务**：有监督域适应（**Supervised Domain Adaptation, SDA**），目标域训练标签合法可用；目标域验证、测试标签不得参与训练、SVD、配对、OT 代价/伪标签或超参数选择中的测试部分。
4. **模态**：可见光 RGB（B4/B3/B2）、**近红外 NIR**（B8）、**结构化 AIS 属性**。B8 **不是热红外**，AIS **不是原始 I/Q 射频信号**。三个模态按**同一个船舶实例**绑定，三路编码后在 JMDA-Net 内对齐/传输/融合；不能把三种输入提前合成普通图片。
5. **源/目标域初版协议**：`day3` 为源域，其余 `day1,2,4,5,6,7,8` 的合并集为目标域。`dayN` 来源于文件名前缀，**尚未独立验证是否等于真实采集日期或具有显著分布差异**。此划分不是官方分类数据集的 192/136 划分，不能混称官方实验。
6. **当前已完成**：COCO 审计、三分类筛选、无场景/MMSI 跨分区交叉的初版划分、314 个 `96×96×4 uint16 .npy` 船舶裁剪、`review` 阶段预览生成。
7. **当前未完成/阻塞**：`67` 条裁剪质检异常仍 `pending`，尚未人工决定 keep/drop；**TIFF 四通道顺序未被独立核实**；`build` 因 pending 67 条主动阻止，**尚未生成正式 RGB + NIR + AIS `.npz`**；JMDA-Net 三模态训练入口尚未为该数据集完成适配；尚无 VDS2Raw 训练结果。
8. **执行策略**：新 Codex 首先检查用户当前仓库和路径/数据文件，不要再次下载数据、重复裁剪或擅自重划分；先协助完成质量复核、波段核实、三模态构建，然后本地 smoke/test，最后把同一套固定协议及预处理状态上传 Linux 服务器训练。
9. **模型历史最终版本**：Tensor 基于因子化多模态外积、交替 SVD 更新投影（不由优化器更新），CostNet/TransNet + Softmax 初始核 + Sinkhorn 双边约束 OT，类别条件耦合与基于 Tensor 稳定性的 OT 预热/ramp。历史 Codex 报告了针对旧私有天气数据的调试与短程验证，**不等于 VDS2Raw 已验证**。

---

## 1. 范围、工程与环境

### 1.1 用户选择

- 本地仓库：`D:\Code\JMDA-Net`。
- Windows 解释器：`D:\Anaconda\envs\pytorch\python.exe`。历史 Codex 在本地报告 PyTorch 2.6.0、CUDA 12.6、RTX 4060 Ti 可用；**新会话应实际验证环境**。
- 方式：**Windows 本地开发与少量数据/epoch 测试；Linux GPU 服务器进行完整实验**。
- 服务器上旧 JMDA 项目历史见 `/home/lixiang/lx/JMDA` 或 `/home/lixiang/lx/JMDA-Net`；这两个路径在历史不同阶段出现过，**以新会话服务器实际位置为准**。旧天气数据曾在 `/mnt/data/lixiang/data/Data/晴天` 等路径，**不能当成 VDS2Raw 的服务器路径**。VDS2Raw 目前确认在 Windows；尚无已验证的 Linux VDS2Raw 目录。
- 研究目标：完成 JMDA-Net 在一个真实公共卫星三模态船舶分类数据集上的**有监督跨采集环境域适应**主实验，要求能够写入论文/返修材料，强调正确性、可重复性和无数据泄漏，禁止“调指标”。

### 1.2 与其他项目的边界

- 原 JMDA-Net：研究 Tensor/TAL + 神经 OT + 域对抗；原私有数据源域晴天，目标域雨天/逆光/黑天/雾天。
- `Dual_D`：另一个独立的双判别器衍生项目，**不是本次新公开数据训练的代码主体**。
- M4-SAR / So2Sat / 专利：不属于本次工作。
- 原始私有数据主模型曾只接入 VIS + 热/成像 IR；AIS I/Q 相关代码主要在单模态与基线中，**历史对话没有证实其已成为当前主模型的第三路输入**。新的 VDS2Raw 数据需要新增结构化 AIS 编码器并实际接入完整训练流程。

---

## 2. JMDA-Net 方法链路与最终历史代码状态（以仓库现状复核为准）

### 2.1 方法流程（预期）

```text
源域有标签 RGB / NIR / AIS ─→ 对应三路编码器 ─┐
                                               ├─ Tensor/TAL 模态-域对齐
目标域有标签 RGB / NIR / AIS ─→ 对应三路编码器 ─┘   ├─ 因子化高阶外积表示
                                                   ├─ 源/目标模态投影 U,V（交替 SVD）
                                                   └─ 融合源/目标特征
                                                           │
                                      Learnable CostNet → TransNet 代价修正
                                                           │
                                      Softmax 初始核 → Sinkhorn 最终传输计划
                                                           │
                                      类别条件跨域传输 → 重心映射
                                                           │
                                      Beta(2,2) 插值 → 残差 MLP 中间域
                                                           │
                                      分类监督 + Tensor 损失 + 域对抗
                                                           │
                                                目标域船舶三分类
```

**准确术语**：对外叙述“源域与目标域**同类别**随机配对”而不是“同一艘船跨域一一物理配对”。VDS2Raw 场景中源/目标是不同日期/环境的图像，配对以训练标签辅助完成；不可把它说成天然同步采样。推理只使用单个目标实例的 RGB、NIR、AIS 三路特征及目标域投影和分类器，不能要求输入源域样本、目标真值或中间域真值。

### 2.2 Tensor/TAL：核心约定

历史 Codex 在 Tensor 模块中已讨论并报告实现：

- 每个领域分别由多模态样本特征外积构造高阶张量的**因子化表示**，避免三路 512 维产生巨大稠密外积张量；数学与收缩操作应核对等价性。
- 逐模态固定其余投影、张量收缩、构造**中心化跨域交叉协方差**，做 SVD，左右奇异向量闭式更新源/目标投影矩阵 `U_m, V_m`。
- `U,V` 在当前预期版本中是 **buffer/无梯度投影**，不放入 AdamW；不是“ALS 计算梯度”，也不是“总损失同时通过 AdamW 更新投影矩阵”。
- Eq.(7) 对有监督同类训练配对的源/目标投影特征求逐样本余弦相似度均值；Eq.(8) 为多模态平均负相关对齐损失。投影固定后该损失反传给**模态编码器**等网络参数。
- 历史最终改动进一步包括：**每 epoch 用训练集统计特征进行 SVD 更新**；固定每次独立运行的同类配对；成对 Procrustes 统一 SVD 基方向；投影坐标变化后同步变换下游分类器、域判别器和 OT 网络的坐标，以避免每个 epoch 打乱学到的表示。
- 历史过程出现过“每 mini-batch 更新 SVD”的早期实现和“每 epoch 更新 SVD”的后期实现；**后者是对话末尾的最终方向**，必须以真实代码、参数和调用位置核对。
- 主要历史文件：`Tensor.py`、`epoch_svd.py`（历史出现过）、`Ablation/module_ablation.py`、`test_tensor_ot_invariants.py`。

### 2.3 神经最优传输：核心约定

- CostNet 学习传输特征/代价，TransNet 学习代价修正；`Softmax` 生成行归一化**初始核**，不能直接把它宣称为满足双边边缘约束的最终 OT 计划。
- Sinkhorn 在可微核上反复行/列缩放，得到满足 `P1=a, Pᵀ1=b`（允许浮点残差）的熵正则传输计划；日志记录最大行/列边缘残差、运输正则目标和代价修正正则。
- 在 SDA 训练中启用**类别条件 OT**：仅允许同一类别的源/目标训练实例传输；检查每个 batch 的共有类别与空行、质量守恒、梯度稳定。
- 用 `P` 对目标训练特征重心映射，并使用行质量归一化，然后 `Beta(2,2)` 插值、残差 MLP 构造中间域样本。
- 分类、对抗和代价正则通过反向传播更新 CostNet、TransNet、MLP、编码器、判别器、分类器等可学习参数；修正历史 KL 方向和 GRL 叠加导致的错误优化方向。
- 历史实现保留三种传输模式供公平消融：`legacy_row_softmax`、`row_softmax`、`sinkhorn`。重要比较：相同修正代价下仅改变是否使用 Sinkhorn 的 `row_softmax` vs `sinkhorn`。
- 主要历史文件：`Generator.py`、`Discriminator.py`、`Ablation/module_ablation.py` 及其内部引用。确保 `Ablation` 包装模块引用唯一有效实现，杜绝副本漂移。

### 2.4 训练调度：历史最终改动

历史对话末尾明确：旧天气数据上直接同时训练 Tensor + OT 性能不稳定，为此加入 **Tensor/SVD 预热 + OT 渐进启用**（不是冻结全部编码器）。对 100 epochs 的最新建议是：

| Epoch | 预期启用内容 |
|---|---|
| 1–10 | 正常训练源/目标监督分类与 Tensor/TAL；每 epoch SVD；OT 生成器/判别器不参与损失优化 |
| 11–15 | OT 权重依次 0.2、0.4、0.6、0.8、1.0；逐步启用中间域分类、对抗、代价修正规则 |
| 16–100 | Tensor + Softmax/Sinkhorn + 神经 OT + 分类 + 域对抗完整联合训练 |

CLI 历史参数：`--ot_warmup_epochs 10 --ot_ramp_epochs 5`，原始主模型/调参参数包括 `--projection_dim 64 --svd_max_sweeps 10 --svd_tolerance 1e-3 --svd_stat_batch_size 128 --transport_mode sinkhorn`。**这些是旧天气数据的历史建议，VDS2Raw 需要本地少量样本核实、不要机械沿用 100 epoch 才检查问题。**

### 2.5 旧天气实验与当前目标不可混用

- Codex 后期同一雨天、10-epoch、单次短诊断报告：无 Tensor/OT 69.23%/Macro-F1 58.33%；Tensor-only 69.23%/61.23%；OT-only 73.08%/60.75%；直接联合 61.54%/64.02%；**加预热联合 96.15%/97.37%**。
- 96.15% 只涉及**单次、26 个旧雨天验证样本**，不是正式 5 次均值，不是 VDS2Raw 结果；不能照搬为论文公开实验性能。
- 历史还记录旧版四天气完整训练及一些严重低性能、随后修复 `VIS/IR` 配对和增强等问题；这些记录只说明“为何最新实现如此”，**任何历史指标均不可与 VDS2Raw 直接拼为可比结果表**。
- 旧入口根目录 `main.py` 历史曾存在硬编码路径、验证随机增强、排除 ACC=100%、随机改写指标等不合规逻辑。**新 Codex 必须全仓审计指标与评价代码，严禁改变测量结果、过滤完美分数、在测试集选最佳 epoch。**

---

## 3. VDS2Raw v2 原始数据事实与路径

### 3.1 Windows 实际目录（历史用户已运行）

```text
D:\Downloads\VDS2Raw\
├─ VDS2Raw (v2)\
│  ├─ imgs\                                  # 389 个 TIFF
│  │  ├─ day1_g_18_coreg.tif
│  │  └─ ...
│  └─ annotations\
│     ├─ train__band_2.json
│     ├─ train__band_3.json
│     ├─ train__band_4.json
│     ├─ train__band_8.json
│     ├─ val__band_2.json ... val__band_8.json
│     └─ test__band_2.json ... test__band_8.json
├─ vds2raw_audit_report.json
├─ stage2_report\
│  ├─ stage2_summary.json
│  ├─ annotation_candidates.csv
│  └─ day_shiptype_counts.csv
├─ threeclass_split\
│  ├─ split_manifest.csv
│  ├─ excluded_rows.csv
│  └─ split_report.json
├─ threeclass_crops_96\
│  ├─ crops\{source_train,target_train,target_val,target_test}\类别\*.npy
│  ├─ previews\
│  ├─ crop_manifest.csv
│  ├─ issues_to_review.csv
│  └─ qc_report.json
└─ threeclass_review\
   ├─ previews\flagged\*.png
   ├─ previews\normal_examples\*.png
   ├─ review_decisions.csv
   └─ review_summary.json
```

**重要**：以上是用户历史 PowerShell 路径和脚本实际输出的重建列表；新 Codex 应 `Test-Path`、查看真实路径，不应假定目录始终在本机相同位置。`threeclass_ready` 目录目前**没有成功构建的证据**。

### 3.2 TIFF 格式：已经真实检查三个文件

用户使用 `tifffile.TiffFile` 实测：

- `day6_g_23_coreg.tif`: `(1668, 2592, 4)`, `axes=YXS`, `uint16`, 1 page；
- `day8_g_35_coreg.tif`: `(1678, 2592, 4)`, `axes=YXS`, `uint16`, 1 page；
- `day1_g_18_coreg.tif`: `(1667, 2590, 4)`, `axes=YXS`, `uint16`, 1 page。

这证明**一个 TIFF 自身有四个通道**；JSON 中四个 band 记录是同一个场景的四组波段标注，不是四张独立 TIFF。389 物理 TIFF ≠ 166×4 文件。166 是**具有标注的场景**，并非所有 389 文件都需要裁剪。

**未证实**：四通道排列是否真的依次 `B2,B3,B4,B8`，各 TIFF 是否一致，是否已经精确配准，是否为同一物理辐射标定。`ImageDescription` 在三张样本里为空。须优先从数据官方元信息、数据生成代码/README、TIFF tags、具原始波段对照的可靠证据验证，必要时小样本可视核对；**不能仅凭 4 通道形状或人工输入 `I_VERIFIED` 认定正确**。

### 3.3 COCO / AIS 标注

- 原检测 JSON 的 `categories` 只有 `vessel`；需要依据 annotation 的结构化 AIS `info[0]['Ship type']` 产生分类标签。
- `info` 结构中含 `Heading`、`Navigational status`、`Length`、`Width`、`Timestamp`、`Ship type` 等；`mmsi` 在 annotation 对象。`AIS` **不在 `.npy` 图像里**。
- `val/test` 的 JSON `annotations` 数组含“外来 image_id”记录；**每次解析必须先用该 JSON 的 `images[].id` 集合过滤**，否则泄漏：

```python
valid_ids = {im['id'] for im in data['images']}
valid_annotations = [a for a in data['annotations'] if a['image_id'] in valid_ids]
```

- 按每个场景/船舶**仅计一次，不要乘四波段**：

| 原检测划分 | 被标注场景 | 有效船舶标注 | 带 AIS 船型 |
|---|---:|---:|---:|
| Train | 105 | 483 | 361 |
| Val | 27 | 119 | 79 |
| Test | 34 | 93 | 65 |
| **总计** | **166** | **695** | **505** |

- `190` 条没有可用 AIS 船型。波段级 `(split, scene, annotation_id)` 关联统计 `2348: 695`；场景级 `2348: 166`，无标注级跨波段关联异常（但不能自动证明像素配准）。原始 Train/Val/Test 检出 8 个跨划分重复 MMSI，这也是**新自定义划分必须强制排除身份交叉**的原因。
- 原始 bbox 有少量越界：Train B3 1、B4 1、B8 3、Val B8 1（波段级事件可指向相同实例）；还存在四波段 bbox 中心差异，须用**统一空间窗口**裁四通道、不能各波段单独随意裁剪。

---

## 4. 官方同名三分类、样本量及自定义跨域划分

### 4.1 分类定义（最终固定）

```text
label 0: Cargo                ← raw AIS Ship type == 'Cargo'
label 1: Fishing              ← raw AIS Ship type == 'Fishing'
label 2: Sailing & Pleasure   ← raw AIS Ship type in {'Sailing', 'Pleasure'}
```

`Tanker` 暂时**不保留**（不是 Tanker 数据错误，而是用户最终选择与官方分类类别保持一致）；不要把 Tanker 合并到 Cargo，不要擅自改成四分类或引入 `Passenger/SAR`。不确定或无 AIS 船型的记录不得直接用作监督真值。原始数据中这些类别的候选数为：

| 类别 | 旧检测 Train | 旧检测 Val | 旧检测 Test | 总计 |
|---|---:|---:|---:|---:|
| Cargo | 71 | 14 | 21 | 106 |
| Fishing | 90 | 23 | 10 | 123 |
| Sailing & Pleasure | 72 | 17 | 10 | 99 |
| **合计** | **233** | **54** | **41** | **328** |

官方分类记录声称三类总 328；官方分类划分另有每类 64 个训练样本（共 192）及 136 个测试样本。**本项目当前是独立定义的跨日 SDA 任务，和该官方 train/test 协议不是同一个 benchmark**。

### 4.2 当前已生成的“第一版跨日 SDA 协议”（已完成逻辑划分）

- 源域：文件名前缀 `day3`；目标域：其余七个 `dayN` 联合；`seed=2026`。
- 源域原有 162 条三分类候选，因同一 MMSI 在目标域也出现，排除源域 14 条，剩余**源域训练 148 条**。目标域有 166 条，分为约 60/20/20：目标训练 100、验证 33、测试 33。
- 使用场景与 MMSI 的**并查集合并分组**，强制每个场景、每个身份属于唯一分区。程序报告 4 分区之间 `scene_overlap=0`、`mmsi_overlap=0`；在最终训练前仍应在实际处理后再次检查。

| 当前分区 (`partition`) | Cargo | Fishing | Sailing & Pleasure | 总计 | 含候选样本场景数 |
|---|---:|---:|---:|---:|---:|
| `source_train` | 20 | 55 | 73 | **148** | 22 |
| `target_train` | 51 | 34 | 15 | **100** | 48 |
| `target_val` | 17 | 11 | 5 | **33** | 16 |
| `target_test` | 17 | 11 | 5 | **33** | 22 |
| **总计** | **105** | **111** | **98** | **314** | 108 |

- `split_report.json` 给出 `eligible_threeclass_before_identity_exclusion=328`、`cross_domain_excluded_source_samples=14`、`used_samples=314`。从 695 条有效标注中排除 367 条非官方三类及 14 条跨域重复身份，`excluded_rows=381`。
- 注意：原始检测 Train/Val/Test 被**重新归并**至新的协议（源域训练甚至包含原始 Test 样本）。因此不能声称符合原始检测/官方分类 benchmark 划分。新协议内部目标测试集必须保持严格独立。
- 当前 `source_train` 类别分布不均（Cargo=20）；`target_val/test` 的 Sailing & Pleasure 各只有 5 条。**不能只跑一次 Accuracy 评价论文性能**；需要多 seed 均值±标准差、逐类 recall/F1、混淆矩阵和置信区间，必要时进一步设计多协议验证，但每个协议要独立锁定、可复现且不按测试分数挑选。
- `day3→其他天` 是**候选 domain shift**：`day3` 在总候选中有 162 个三分类观测，其他 7 日有 166 个，且类别比例差异大；要评估它是否体现采集日/环境变化，而不只是类别或背景差异。不要把 day1…day8 未查证地写成雨天/雾天/夜间等真实天气域。

### 4.3 数据划分/文件身份主键

- 船舶主键：`sample_id = scene_filename + '::' + annotation_id`，例 `day3_g_0_coreg.tif::578`。
- 一个 `sample_id` 要始终绑定**同一**标签、scene、MMSI、四通道图像、AIS 记录与 `partition`。
- 现有 `split_manifest.csv` 是**权威划分来源**；模型 Dataset/DataLoader 必须读取它或后续等价导出 manifest 的 `partition`，不要重新 `train_test_split`、按目录随机拆，也不要沿用原天气实验 `train+val` 合并规则。

---

## 5. 已完成的裁剪与 QA：下一步从这里继续

### 5.1 裁剪已经完成

用户运行 `crop_vds2raw_threeclass.py`，已生成：

- **314/314** 个裁剪 `.npy`；每个是**原始四通道图像** `shape=(96,96,4)`、`dtype=uint16`，数据按源 TIFF 通道原顺序，**不是融合的 RGB+NIR+AIS**。
- 只从本次初版划分涉及的**108 个被标注场景**读取数据（与 166 个总标注场景、389 个所有 TIFF 均不同）。
- 输出 `D:\Downloads\VDS2Raw\threeclass_crops_96\crops\...`、`crop_manifest.csv`、`issues_to_review.csv`、`qc_report.json`、预览图。
- 四个波段的 bbox **不完全一致**，脚本按联合范围选择同一裁剪中心、统一 96×96 窗口，以保证四通道实际像素位置绑定。

### 5.2 质量报告的准确含义

`qc_report.json` 证实：

| 项目 | 样本数 |
|---|---:|
| 成功生成 | **314** |
| 无 QA 标记 | **247** |
| 至少一项 QA 标记，需要人工复核 | **67** |
| `other_annotated_ship_center_in_crop` | 56 |
| `edge_zero_padding` | 13 |
| `annotation_outside_image` | 1 |

后三项**有交集，不能相加得 70 条不同样本**。此外仅根据“其他已标注船舶中心入框”能检测部分相邻目标，不代表没有未标注船舶。对一些单目标分类样本，这项尤为重要。

### 5.3 review 阶段用户真实完成状态

用户运行：

```powershell
$py = 'D:\Anaconda\envs\pytorch\python.exe'
& $py -u 'D:\Downloads\prepare_vds2raw_three_modal.py' review `
    --crops 'D:\Downloads\VDS2Raw\threeclass_crops_96' `
    --all-annotations-csv 'D:\Downloads\VDS2Raw\stage2_report\annotation_candidates.csv' `
    --out 'D:\Downloads\VDS2Raw\threeclass_review'
```

真实终端输出：`Review prepared: 300/314`、`Flagged: 67 Normal: 247`、`Decisions: {'keep': 247, 'pending': 67}`。预览：`threeclass_review\previews\flagged\`；**黄色框是本目标跨波段 bbox 联合框、红色框是附近其他已标注船舶**（颜色只是 UI 标注，不是 RGB 原始真实色彩）。

用户紧接着执行 `build`，得到：

```text
ValueError: 67 samples pending review ...
Mark keep/drop in review_decisions.csv, or use --pending-policy exclude.
```

**这不是处理代码崩溃**，是脚本的保护机制；因此 **`threeclass_ready` 尚未完成构建**。新 Codex 应指导/帮助用户审核 67 张预览，并在 `threeclass_review\review_decisions.csv` 中把 `pending` 改为 `keep` 或 `drop`。对于**有 QA 标记而保留**的记录，脚本要求 `notes` 不为空。`review` 重跑默认能保留已有决策，使用 `--reset-decisions` 会覆盖，应避免误用。

人工审核建议：目标主体不完整、多个同级主目标导致标签不唯一、严重边缘截断 → 倾向 `drop`；邻船很小且主目标明确、少量零填充不影响目标 → 可 `keep` 并记录理由。**不要自动把全部 67 条改 keep/drop**，不要仅凭模型预测自动审核；可用批量缩略图、CSV 标注效率工具辅助人类决定。

开发阶段可以用 `--pending-policy exclude` **临时只导出 247 条无 QA 标记样本**做 smoke，但必须输出到新 trial 目录，不能写入最终论文实验报告，也不能把 247 视为最终确认样本。任何 drop 导致划分/类别变化，最终必须重新核验每个分区的数量、MMSI、场景和类别覆盖。

---

## 6. 三模态 `.npz` 构建脚本与待核验项

### 6.1 现成脚本

下载/保存到 Windows 的脚本名：`D:\Downloads\prepare_vds2raw_three_modal.py`。

`build` 预期输出：

```text
D:\Downloads\VDS2Raw\threeclass_ready\
├─ samples\source_train\{Cargo,Fishing,Sailing_Pleasure}\*.npz
├─ samples\target_train\...\*.npz
├─ samples\target_val\...\*.npz
├─ samples\target_test\...\*.npz
├─ dataset_manifest.csv
├─ feature_schema.json
└─ build_report.json
```

每个 `.npz`（构建成功后）包含：

| 键 | 数据 | dtype、形状 |
|---|---|---|
| `rgb` | B4/B3/B2 三个可见光反射通道 | `uint16`, `(3,96,96)` |
| `nir` | B8 单通道近红外 | `uint16`, `(1,96,96)` |
| `ais` | AIS 属性编码向量 | `float32`, `(F,)` |
| `ais_mask` | AIS 特征有效性掩码 | `float32`, `(F,)` |
| `label` | 3 类整数标签 | `int64` scalar |

- 每个样本只能属于一个分区；`dataset_manifest.csv` 保留 `sample_id`、`partition`、`scene`、`day`、原始 `split`、`annotation_id`、`mmsi`、QC 注释。
- 数据导出是**保存三路对齐输入，不是提前融合特征**。

### 6.2 构建命令（只在审核和真实波段顺序验证完成后使用）

```powershell
$py = 'D:\Anaconda\envs\pytorch\python.exe'
& $py -u 'D:\Downloads\prepare_vds2raw_three_modal.py' build `
    --root 'D:\Downloads\VDS2Raw\VDS2Raw (v2)' `
    --crops 'D:\Downloads\VDS2Raw\threeclass_crops_96' `
    --review-dir 'D:\Downloads\VDS2Raw\threeclass_review' `
    --out 'D:\Downloads\VDS2Raw\threeclass_ready' `
    --band-order 'B2,B3,B4,B8' `
    --confirm-band-order 'I_VERIFIED'
```

**重要**：`--band-order 'B2,B3,B4,B8'` 是**示例顺序，并非已核实事实**；`I_VERIFIED` 只是一个确认标记，并不能验证内容。若实际顺序不同必须替换。`build` 拒绝非空输出目录，避免混入旧数据；确认正式导出时应使用全新/空的输出路径。

### 6.3 AIS 特征规则：目前脚本的已实现逻辑

- 依据 `(original_split, scene, annotation_id)` 从 `annotations/{train,val,test}__band_2.json` 找标注，先以该 JSON 的 `images` 过滤外来 image_id；验证 MMSI、AIS `Ship type` 和 manifest 分类是否一致。
- `Heading` → sin/cos 编码；`Length`、`Width` → 连续数值，仅用 `source_train + target_train` 估计均值、标准差；`Navigational status` → 仅用这两个训练分区拟合类别词表并进行 one-hot；缺失/无效字段用掩码表示。
- 明确排除用于模型输入的字段：`Ship type`、`Cargo type`、`MMSI`、`Name`、`coordinates`、`distance`、`Timestamp`、`day`、`scene`；有些保留在清单用于溯源/划分，不能交给网络直接学习。
- AIS `Timestamp` **不等于 Sentinel-2 采集时间**，在无可靠匹配前，不生成时间差输入。
- **注意新的技术风险**：`Length/Width` 与船型强相关，即使未直接输入 Ship type，也可能形成 AIS 主导的捷径。要求 RGB-only、NIR-only、AIS-only、双模态及三模态消融，不可只报告全模态 Accuracy。
- 图像保持 `uint16`；后续训练加载器才依据**训练分区**统计建立归一化（不应直接对未标定的 uint16 用 ImageNet `Normalize`）。必须保留原始 16-bit 数据，不应无说明转为 8-bit 造成动态范围丢失。

### 6.4 建议新增的构建校验

在 `build` 前后都做：

1. 四通道 TIFF 波段顺序、所有/抽样场景尺寸与通道数、动态范围、零值比例及对齐核查。
2. CSV `sample_id` 唯一；`npz` 文件数=keep 数；各分区/class 数正确且均有三类。
3. 检查每个样本的 `.npz` 是否含全部五个键，形状/dtype/有限值正确；`AIS` 与其 image 对应同一 `(scene, annotation_id, MMSI)`；禁止重复并行拼接错误。
4. 核查训练分区拟合的 AIS 标准化/词表**未访问 target_val 或 target_test**。
5. 确保单模态/多模态变换共享同一船舶 sample ID；同步空间变换。**AIS Heading 是绝对航向，若图像旋转/镜像而不相应转换角度，会破坏图像–AIS 语义一致性**；在缺少地理方向约定前，建议暂禁随机翻转和旋转，仅用不会改变方向含义的增强。
6. 不在数据划分完成后随意把 `drop` 的样本替换成另外日期/原 Test 样本；必要时重新生成**完整新协议版本**并重新完成无泄漏审计。测试分区在开发阶段只用于路径/张量格式读取测试（可做无标签测试），其真值不用于选模或调参。

---

## 7. JMDA-Net 对接 VDS2Raw 的具体改造路线

**不得**把旧天气用 `DataLoad.py` 或 `Ablation/paired_dataset.py`（基于 VIS/IR 文件名、旧天气目录和 `train+val` 合并划分）直接指向新的 `.npz` 目录。建议实现**独立 VDS2Raw Dataset/Loader + 三模态训练入口或数据后端**，复用最新 Tensor、OT、训练和评价核心，避免影响旧天气主实验。

### P0：只读现状审计（开始 Codex 新对话后的第一项）

- `git status --short --branch`；记录最新 commit 和未提交修改。不要直接覆盖工作区。
- 搜索并**实际阅读**：`Tensor.py`、`Generator.py`、`Discriminator.py`、`Models.py`、`DataLoad.py`、`Ablation/module_ablation.py`、`Ablation/paired_dataset.py`、`Ablation/PairedClassSampler.py`、`epoch_svd.py`（若存在）、`test_tensor_ot_invariants.py`、`metrics_utils.py`；确认旧包装引用路径，查看 `--help`。
- 验证 3 种 transport 模式、SVD 更新频率、Procrustes 与下游坐标同步、类别条件 OT、预热逻辑是否**真的存在且被运行路径使用**。若历史代码与当前不符，以 Git/实际源码为准，说明差异再采取修复。
- 验证本地 Python/PyTorch GPU、依赖和用户数据/审核文件实际存在。先读取 `review_decisions.csv` 统计，检查用户是否后来完成审核；此交接时间点仍有 67 pending。
- 核查是否有随机改写结果、按测试精度调参、验证随机数据增强、样本替换等遗留逻辑，主动修复或绕过，**不要照旧调用有问题的 metrics_utils**。

### P1：数据质量审核 + 波段核实

- 打开 `threeclass_review\previews\flagged`，以批量审阅方式帮助用户完成 67 例的 `keep/drop` + `notes`（用户确认才写入）。
- 核实 4 通道与 B2/B3/B4/B8 的真实映射。若证明不足，不能写 `I_VERIFIED` 继续正式导出。
- 确认 96×96 裁剪对小尺寸目标的有效性。保留样本质量表与审核统计，防止无意中只保留较容易的场景/类别。

### P2：构建真实三模态文件并锁定 manifest

- 使用/必要时修正 `prepare_vds2raw_three_modal.py` 的 `build`。
- 生成 `dataset_manifest.csv`、`feature_schema.json`、`build_report.json`；输出保存在 Windows **独立版本化目录**，例如 `threeclass_ready_v1`。
- 建立强断言（样本数、唯一性、scene/MMSI 无泄漏、维度、AIS 关联、标签、图像域归一化参数与数据版本 SHA256）。

### P3：开发三路 Dataset/编码器与完整端到端流

- 实现 `VDS2RawThreeModalDataset`，从 `dataset_manifest.csv` 读取 `.npz`；返回 `rgb`, `nir`, `ais`, `ais_mask`, `label`, `partition`, `sample_id`（后两者用于追溯，不喂模型）。
- RGB 采用适合三通道的图像编码器（例如项目原 ResNet18）；NIR **一通道**可通过适配首层卷积/专用 CNN 编码器；结构化 AIS 用**小型 MLP**（可拼有效性掩码），不使用处理原始 AIS I/Q 的 CVNN 分支。
- 把三路各映射至与 Tensor 模块兼容的维度，但要控制高阶运算显存；严禁实际分配 512×512×512 大张量。
- 与旧模型结构统一，核对 `Tensor.py` 所需模态列表 `M=3`、特征/投影维度、融合后 `Classifier`、`Generator`、`Discriminator` 的输入输出维度。**严禁仅对 `.npz` 做图像通道拼接后称“三模态 JMDA-Net”。**
- SDA 训练仅 `source_train + target_train` 带真值；同类配对 sampler 不依赖目标 val/test，适应源/目标不平衡及 batch 内类别缺失；同一组配对用于对齐/必要的类条件 Sinkhorn。每 epoch 统计需完整覆盖合法目标训练样本，消除早期有放回采样漏样问题。
- 读取/验证 checkpoint 应包含编码器、Tensor 的 SVD buffers、OT 网络、分类器、判别器、AIS schema 与 normalization 等元数据；推理不依赖目标训练/验证标签。

### P4：本地测试，不要直接跑 100 epoch

最少测试：

1. 单个样本和四个分区的 DataLoader smoke：图像 `[B,3,H,W]`、`[B,1,H,W]`、AIS `[B,F]`、mask `[B,F]`，标签 0/1/2。
2. 一个有源/目标同类配对的 batch，全部网络前向/反向，CUDA/CPU 张量设备一致；无 NaN/Inf，损失方向正确，部分可训练参数梯度非零。
3. 模态数 3 时 Tensor 的因子化投影与小尺寸稠密张量的等价性；SVD 正交性、Procrustes 投影空间稳定、跨 epoch 更新后坐标转换不破坏固定输入预测（适当容差）。
4. 类条件 Sinkhorn：只在同类间有质量、总运输质量守恒、边缘误差足够小、无共享类别时明确处理而非 NaN；比较 `row_softmax`、`sinkhorn` 的列边缘约束差异。
5. loss + checkpoint + resume + 固定随机种子复现、eval 模式和数据增强关闭。严格测试：**打乱 AIS 样本 ID** 应造成一致性测试失败，而不是仍静默可用。
6. 用可控子集运行 1–3 epoch，再执行较短但覆盖 warmup/ramp 的 smoke；**第一条完整训练日志必须记录四分区每类数量、模态形状、AIS 特征维、SVD 和 Sinkhorn 诊断**。

### P5：Linux 服务器部署与正式实验

- 本地代码版本固定，建议 Git commit/保存 git diff 与 data manifest 校验和；原始数据或经过 QA 的 `.npz` 由用户批准后上传服务器，避免重传全部 389 张 TIFF（需要在服务器重做辐射校准时另论）。
- **先确认服务器实际目标目录、Conda 环境、GPU 可用显存和磁盘空间**，再给精确 rsync/scp/sftp 命令；不要把旧私有天气路径当作本项目数据路径。
- 在服务器上重跑 dataset audit、单 batch forward/backward、1 epoch、checkpoint 恢复等预检；之后固定协议完成多种随机种子训练，日志落地 CSV+JSON+原始 .log，推荐 nohup/tmux 管理。
- 100 epochs、warmup 10+ramp 5 是历史可复现默认候选，先看该小数据集早停与过拟合风险；验证只看 `target_val`，`target_test` 在最终配置固定后**单独评估**。不要在 test 上反复挑 seed/epoch。

### P6：报告与消融设计（完成正式训练后）

最少建议：

- 完整 RGB+NIR+AIS + Tensor + Sinkhorn + 预热模型；
- Tensor-only、OT-only、neither 两个模块消融；
- `row_softmax` vs `sinkhorn` 的**公平对照**（可补充 `legacy_row_softmax`）；
- RGB-only / NIR-only / AIS-only / RGB+NIR / RGB+AIS / NIR+AIS / all-three（按资源逐步安排，合理共享网络和训练配置，不做不公平参数量比较）；
- 预热策略 vs 直接联合训练；
- 多 seed 的 Accuracy、Macro-Precision、Macro-Recall、Macro-F1（固定全 3 类口径）、per-class F1、混淆矩阵、各域/每类样本数、均值±标准差与可复现 manifest；
- 重要有效性实验：AIS 标签代理偏差、同身份/同场景分组保护、跨日期域差异证据，以及不同裁剪大小/训练图像归一化的敏感性。

所有消融必须在**完全相同的划分、质检版本、seed 集、epoch、选模规则**下进行；如输入模态减少，严格说明网络容量/配对样本数是否变化。只有固定的**独立 target_test** 可以当最终测试依据。

---

## 8. 需要新 Codex 优先排查的高风险点

| 严重性 | 风险 | 对策/完成标准 |
|---|---|---|
| P0 | 67 QA 样本未经审核；`build` 当前主动失败 | 保留审核决策 CSV；无 pending 后正式构建；所有 flagged keep 必有说明 |
| P0 | TIFF 四通道映射未核实 | 使用可信证据验证通道顺序，必要时中止正式导出 |
| P0 | `.npy` 只是图像，未含 AIS、未形成正式 `.npz` | 每个 sample_id 的 RGB/NIR/AIS 一对一绑定并自动断言 |
| P0 | 旧 `paired_dataset.py` 会按照旧天气同名文件、甚至合并旧 train+val 的方式重分数据 | VDS2Raw 独立 loader，始终按锁定的 `partition` |
| P0 | 目标 test 数据泄漏 | 单独 `target_test`；不入 SVD/OT/预训练统计或选模 |
| P0 | 根目录旧 metrics 代码可能修改数值 | 全仓审计、移除任何指标随机替换/完美结果过滤 |
| P1 | Source Cargo=20，target_test Sailing/Pleasure=5，极小样本 | 分组 5 seed、置信区间、per-class 结果；声明统计限制 |
| P1 | AIS Length/Width 与类高度相关（代理捷径） | AIS-only 与图像-only 消融，检查标签字段完全排除 |
| P1 | `day3` vs 其余天的分布差异未被验证 | 报告采集日证据、影像统计与类别分布；不称特定天气 |
| P1 | 旧 VIS+热红外/IQ 与 VDS2Raw RGB+NIR/结构化 AIS 数据形式不同 | 更换专用分支编码器，论文明确边界与迁移设置 |
| P1 | Sinkhorn 类别支持/边缘约束在三分类小 batch 不稳定 | batch 构成审计、边缘残差、NaN/Inf checks |
| P1 | SVD 频繁换基破坏下游权重 | 检查 epoch SVD、Procrustes 与同步基变换是否真正执行 |
| P1 | 训练增强旋转/翻转与 AIS Heading 矛盾 | 核实航向与图像方向关系；未验证前禁用此类增强 |
| P2 | 原始 COCO val/test JSON 中有外来 annotations | 每次按 `images[].id` 过滤，避免重复计数/跨划分污染 |
| P2 | 原始 Train/Val/Test 不等于新的 DA 分区 | 仅报告自定义协议，记录原始 split 只用于 AIS 关联 |

---

## 9. 新 Codex 推荐交付物和验收标准

按顺序在仓库中交付/更新（文件名可适配现有架构，但应保持含义）：

- `docs/VDS2Raw_3class_SDA_protocol.md`：最终样本、域、类、身份分组、质检/波段证据、数据保护协议及限制。
- `datasets/vds2raw_three_modal.py`：Manifest 驱动 Dataset、训练/验证无泄漏归一化和 `sample_id` 对齐。
- `models/ais_encoder.py`：结构化 AIS MLP（或仓库现有模块内等价实现），严格用 schema 确定输入维。
- `train_vds2raw.py` / 合理的 `module_ablation.py` 子入口：三模态 SDA 完整训练、稳定 Tensor/Sinkhorn 调度、配置保存、检查点保存/恢复。
- `tests/test_vds2raw_data.py`、`tests/test_vds2raw_three_modal_smoke.py`：配对、泄漏、张量形状、OT、梯度和复现检查。
- `scripts/preflight_vds2raw.ps1`（Windows）及 `scripts/run_vds2raw_server.sh`（Linux）：以用户确认的真实数据路径为参数，而非旧天气硬编码。
- 每次实验产物：`config.yaml/json`、`manifest hash`、`git commit`、`seed`、独立 `.log`、逐 epoch CSV、最优 checkpoint、每类测试预测 CSV（可选）、`summary.json`、最终统计表。

**最低验收**：三模态真输入；所有样本/标签关联准确；目标 Val/Test 未入任何训练统计；四分区 scene/MMSI 无交叉；Tensor 和 OT 在三模态前向/反向无异常；所有输出指标真实可追溯；本地 smoke 通过、Linux 上至少一次完整测试流程成功后再启动重复长训练。

---

## 10. 建议最先执行的只读 PowerShell 检查

```powershell
$py = 'D:\Anaconda\envs\pytorch\python.exe'
$repo = 'D:\Code\JMDA-Net'
$base = 'D:\Downloads\VDS2Raw'

Test-Path $repo
Test-Path (Join-Path $base 'VDS2Raw (v2)\imgs')
Test-Path (Join-Path $base 'threeclass_split\split_manifest.csv')
Test-Path (Join-Path $base 'threeclass_crops_96\crop_manifest.csv')
Test-Path (Join-Path $base 'threeclass_review\review_decisions.csv')

Set-Location $repo
git status --short --branch
& $py -c "import sys,torch; print(sys.executable,torch.__version__,torch.cuda.is_available())"

Import-Csv 'D:\Downloads\VDS2Raw\threeclass_review\review_decisions.csv' |
  Group-Object decision | Select-Object Name,Count
```

如果 `review_decisions.csv` 此时仍有 67 `pending`，先执行质检，**不要先给出正式 build 成功、正式三模态训练可启动等结论**。

---

## 11. 重要来源与状态证据索引

**对话和源文件**：

1. 用户上传 Codex 全记录：`粘贴的文本 (1)(4).txt`，约 8,845 行。关键讨论范围：
   - 方法早期与旧代码不一致约 `178–419`；SVD 重构约 `897–1004`；监督配对、OT/Sinkhorn 与 Tensor 理论约 `1007–2262`；
   - VDS2Raw 数据来源与 AIS/JSON 路径约 `5770–5931`；公开三模态定义约 `3080–3175`；
   - 旧天气代码配对/SVD 基变换修复约 `8375–8442`；预热代码、结果及训练计划约 `8490–8845`。
2. 本次对话中用户提供的 `vds2raw_audit_report.json`、`stage2_summary.json`、`annotation_candidates.csv`，核实 389 TIFF、12 JSON、695 / 505 / 328 以及四波段关联。
3. `split_vds2raw_threeclass.py`、`threeclass_split/split_manifest.csv`、`threeclass_split/split_report.json`，核实 328→314、四分区样本数与无场景/MMSI 交叉。
4. `crop_vds2raw_threeclass.py`、`threeclass_crops_96/crop_manifest.csv`、`qc_report.json`、`issues_to_review.csv`，核实 314 成功裁剪、67 QA 标记。
5. `prepare_vds2raw_three_modal.py`，其 `review` 与 `build` 子命令、AIS schema、keep/drop 规则和待审核保护机制。用户 PowerShell 运行证明 review 已生成，build 因 pending 主动中止。
6. 官方原始 VDS2Raw v2 数据记录（背景参考）：<https://zenodo.org/records/13889073>；官方分类子集：<https://zenodo.org/records/14847258>；数据论文：<https://arxiv.org/abs/2411.03403>。**后续若引用为事实，请 Codex 根据实际在线文档重新核实，不能以本交接替代文献核查。**

**状态分类**：
- **用户实测**：Windows 路径、实际 TIFF shape、review 输出与 build 异常信息。
- **审计/脚本报告**：数据计数、划分统计、裁剪 QC、无跨组场景/MMSI 的逻辑检查；正式训练前需复核实际落盘数据。
- **历史 Codex 声称并在旧环境测试过**：SVD/OT/配对/预热修改、雨天小样本诊断、旧模型测试通过。新 Codex 需核对仓库真实代码。
- **尚未完成**：67 条人工 QA、TIFF channel 顺序可信验证、正式 3 模态 build、VDS2Raw 的 JMDA-Net 训练与消融、Linux 正式部署、最终指标。

---

## 12. 直接复制给新 Codex 的首条指令

> 我现在要继续 `D:\Code\JMDA-Net` 项目中 **VDS2Raw v2 公开数据集的 JMDA-Net 三模态有监督跨域训练**。请先完整阅读附带的 `JMDA_Net_VDS2Raw_Codex_交接文档_2026-10-09.md`。它总结了先前 Codex 全部技术讨论、我在 ChatGPT 中完成的真实数据审计、314 条裁剪、跨域划分和 67 条待人工审核样本。
>
> **先不要直接开始正式训练，也不要擅自重划分数据或把旧天气代码当成 VDS2Raw 数据加载器。** 请首先只读检查仓库 Git 状态、关键 Tensor/Sinkhorn/预热实现、当前脚本与用户本地路径，逐项核对交接文档中“已完成/待完成”的真实性，列出差异、阻塞项及精确的下一步实施计划。随后在保持 `source_train/target_train/target_val/target_test` 和场景/MMSI 无交叉约束的前提下：协助我审核 67 条质量标记、可信确认 TIFF 四通道 B2/B3/B4/B8 映射；构建 RGB+NIR+结构化 AIS 三模态文件并通过一致性测试；为当前 JMDA-Net 实现三路编码和完整 SDA 训练；在 Windows 本地进行 smoke 和必要的短程实验；最后根据确认的 Linux 服务器环境部署多随机种子正式训练。
>
> 模型请以仓库中经过验证的**交替 SVD/Tensor + CostNet/TransNet + Softmax 初始核 + Sinkhorn + 类别条件 OT + 预热/ramp**为起点。禁止将 B8 描述为热红外、将解码 AIS 描述为 I/Q，禁止 AIS Ship type/MMSI 作为输入，禁止目标验证/测试数据泄漏、伪造指标或使用测试集选模。请先给出当前状态审计与阻塞项，然后按阶段实际修改、测试、输出日志与结果。优先就现有数据和脚本继续，不要重复下载或生成已有文件。

---

**给新 Codex 的最后提醒**：如果当前工作区源代码、运行日志与上述历史描述冲突，优先信任**当前源码、实际文件、可复现实测结果**；请明确报告差异，不能把过去聊天中的某条“代码已修改/测试已通过”当成当前仓库已验证的事实。
